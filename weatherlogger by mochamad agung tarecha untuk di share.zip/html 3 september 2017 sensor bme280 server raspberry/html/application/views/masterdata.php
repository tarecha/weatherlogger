<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php 
foreach($css_files as $file): ?>
	<link type="text/css" rel="stylesheet" href="<?php echo $file; ?>" />
<?php endforeach; ?>
<?php foreach($js_files as $file): ?>
	<script src="<?php echo $file; ?>"></script>
<?php endforeach; ?>
</head>
<body>
	<center> <H2>Halaman Management Data</H2><br>
		 <H3>Weather Logger by Mochamad Agung Tarecha</H3></center>
	
	<br>
	 <a href='<?php echo site_url('masterdata/DataManagement')?>'>Log Data Management</a> |
	  <a href='<?php echo site_url('masterdata/NodeProperties')?>'>Node Properties</a> |	
	
	 <a href='<?php echo site_url('../grafik.php?node=N1')?>' target="_blank">Grafik All</a> | 
         <a href='<?php echo site_url('../grafikwaktu.php')?>' target="_blank">Grafik Filter Waktu</a> | 
	 <a href='<?php echo site_url('../grafiklast24hour.php?node=N1')?>' target="_blank">Grafik last 24 Hour</a> 
    <div>
		
		<?php echo $output; ?>
		
    </div>
</body>
</html>
