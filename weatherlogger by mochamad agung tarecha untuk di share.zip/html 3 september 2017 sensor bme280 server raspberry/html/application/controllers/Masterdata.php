<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Masterdata extends CI_Controller {

	public function __construct()
	{
		parent::__construct();

		$this->load->database();
		$this->load->helper('url');

		$this->load->library('grocery_CRUD');
	}

	//ini untuk panggil viewnya
	public function _example_output($output = null)
	{
		$this->load->view('masterdata.php',(array)$output);
	}



	public function index()
	
	{
		
		$this->_example_output((object)array('output' => '' , 'js_files' => array() , 'css_files' => array()));
		
	}

	public function nodeproperties()
	{
		$crud = new grocery_CRUD();
 
 
		$crud->set_table('nodeproperties');
		$crud->set_subject('Node Properties');
		$crud->columns('idnode','lokasi','latitude','longitude','altitude','tes');
		$crud->display_as('idnode','ID Nodes');
		$crud->display_as('lokasi','Lokasi');
		$crud->display_as('latitude','Latitude Decimal Degree');
		$crud->display_as('longitude','Longitude Decimal Degree');
		$crud->display_as('altitude','Altitude Above Sea Level Meter');
		$crud->order_by('idnode','asc');
		$crud->add_action('Graphic All Date',base_url().'image/line1.png','','',array($this,'getgraphicall'));
		$crud->add_action('Graphic Current Date',base_url().'image/line2.png','','',array($this,'getgraphiccurrentdate'));
		$crud->add_action('Graphic Filter Date',base_url().'image/line3.png','','',array($this,'getgraphicfilterdate'));
		$crud->add_action('Get Map Node Location',base_url().'image/maps.png','','',array($this,'getnodemaplocation'));
		

		$output = $crud->render();
 
		$this->_example_output($output); 
	}
	function getgraphicall($primary_key)
	{
		return base_url().'grafik.php?node='.$primary_key.'" target="_blank';
		
	}
	function getgraphiccurrentdate($primary_key)
	{
		return base_url().'grafiklast24hour.php?node='.$primary_key.'" target="_blank';
		
	}
	function getgraphicfilterdate($primary_key)
	{
		return base_url().'grafikwaktu.php?node='.$primary_key.'" target="_blank';
		
	}
	function getnodemaplocation($primary_key,$row)
	{
		return 'https://www.google.com/maps/place/'.$row->latitude.','.$row->longitude.'" target="_blank';
		
	}
	public function datamanagement()
	{
		$crud = new grocery_CRUD();
 
 
		$crud->set_table('masterdata');
		$crud->set_subject('Master Data Log');
		$crud->columns('iddata','waktu','idnode','hum','temp','press','sync1','sync2');
		$crud->display_as('iddata','ID Data');
		$crud->display_as('idnode','Node Name');
		$crud->display_as('waktu','Waktu');
		$crud->display_as('hum','Humidity (%)');
		$crud->display_as('temp','Temperature (oC)');
		$crud->display_as('press','Presure (hPa)');
		$crud->display_as('sync1','Sync Slave Server 1');
		$crud->display_as('sync2','Sync Slave Server 2');
		$crud->callback_column('sync1',array($this,'statusSync'));
		$crud->callback_column('sync2',array($this,'statusSync'));
		$crud->order_by('waktu','desc');
		//karena untuk display data saja makan add, edit, delete dihilangkan
		//data pure dari sensor
		$crud->unset_add();
		//$crud->unset_edit();
		$crud->unset_delete();
		
		
		
		
		$output = $crud->render();
 
		$this->_example_output($output); 
	}
	
	public function statusSync($value, $row)
	{
		
		if ($value == 1)
			return "<img src=".site_url('../image/check.png')."  height='15' width='15' > Done</img> ";
		else
			return "<img src=".site_url('../image/notcheck.png')."  height='15' width='15' > Not Yet</img> ";
		
	}

	

	

	


}
